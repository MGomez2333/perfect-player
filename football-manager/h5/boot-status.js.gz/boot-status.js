/* Small classic-script loader guard. Works even when the game bundle cannot run. */
(function () {
  var idleTimer, started = Date.now(), done = false, recovering = false, stage = '正在加载游戏程序和球员资料…';
  function recovery(titleText, copyText, onRetry) {
    clearTimeout(idleTimer);
    var node = document.querySelector('#app .loading');
    if (!node || done) return;
    recovering = true;
    var screen = document.querySelector('.startup-screen');
    if (screen && screen.classList) screen.classList.add('is-error');
    node.textContent = '';
    var title = document.createElement('h2');
    title.className = 'startup-error-title'; title.textContent = titleText;
    var detail = document.createElement('p');
    detail.className = 'startup-error-copy'; detail.textContent = copyText;
    var retry = document.createElement('button');
    retry.className = 'startup-retry'; retry.textContent = '重新连接';
    retry.onclick = function () {
      if (retry.disabled) return;
      retry.disabled = true;
      progress('正在重新连接虎扑账号…');
      onRetry();
    };
    var note = document.createElement('p');
    note.className = 'startup-error-note'; note.textContent = '已有生涯会保留';
    node.appendChild(title); node.appendChild(detail); node.appendChild(retry);
    node.appendChild(note);
  }
  function fail(reason) {
    if (recovering) return;
    recovery('暂时未能进入游戏', reason + '（启动步骤：' + stage + '）', function () { location.reload(); });
  }
  function progress(text) {
    recovering = false;
    stage = text; clearTimeout(idleTimer);
    var screen = document.querySelector('.startup-screen');
    if (screen && screen.classList) screen.classList.remove('is-error');
    var node = document.querySelector('#app .loading');
    if (node && !done) node.textContent = text;
    var current = /存档|档案/.test(text) ? 'save' : /账号/.test(text) ? 'account' : 'resources';
    document.querySelectorAll('[data-boot-stage]').forEach(function (item) {
      if (item.getAttribute('data-boot-stage') === current) item.setAttribute('aria-current', 'step');
      else item.removeAttribute('aria-current');
    });
    idleTimer = setTimeout(function () { fail('等待响应超时，请检查网络后重试；原存档未被清除'); }, 25000);
  }
  window.__glmBoot = { progress: progress, fail: fail, connectionFailed: function (onRetry) {
    recovery('暂时没连上账号', '请确认已在虎扑 App 内登录，再点击重试。', onRetry);
  }, ready: function () { done = true; clearTimeout(idleTimer); }, started: started };
  window.addEventListener('error', function (event) {
    var target = event.target;
    if (target && target.tagName === 'SCRIPT') fail('游戏资源未加载成功');
    else if (!done) fail('游戏程序启动异常，请使用最新修复包');
  }, true);
  window.addEventListener('unhandledrejection', function () { if (!done) fail('启动请求失败，请重新连接'); });
  progress(stage);
})();
